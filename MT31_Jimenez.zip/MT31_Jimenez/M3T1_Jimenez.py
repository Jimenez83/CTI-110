#CTI-110
#Juan F. Jimenez
#6 Nov. 2017
print ("Hello World")
print ("I need to learn this thing")
print ("I need to pass this class")
